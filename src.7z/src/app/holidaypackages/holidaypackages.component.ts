import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-holidaypackages',
  templateUrl: './holidaypackages.component.html',
  styleUrls: ['./holidaypackages.component.css']
})
export class HolidaypackagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
