import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule }          from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';



import { AppComponent } from './app.component';
import { HeroesComponent } from './heroes/heroes.component';
import { HolidaypackagesComponent } from './holidaypackages/holidaypackages.component';
import { NavigationbarComponent } from './navigationbar/navigationbar.component';
import { BranchesComponent } from './branches/branches.component';

const appRoutes: Routes = [
  { path: 'holidaypackages', component: HolidaypackagesComponent },
  { path: 'heroes', component: HeroesComponent },
   { path: 'branches', component: BranchesComponent },
];

@NgModule({
  declarations: [
    AppComponent,
    HeroesComponent,
    HolidaypackagesComponent,
    NavigationbarComponent,
    BranchesComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    HttpClientModule,
     RouterModule.forRoot(
      appRoutes,
      { enableTracing: true } // <-- debugging purposes only
    )
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
