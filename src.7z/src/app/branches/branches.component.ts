import { Component, OnInit } from '@angular/core';
import { BranchService } from '../branch.service';
import {Article} from '../article';

@Component({
  selector: 'app-branches',
  templateUrl: './branches.component.html',
  styleUrls: ['./branches.component.css']
})
export class BranchesComponent implements OnInit {

 
 articles : Article[];
 statusCode : any;

  constructor(private branchService: BranchService) { 
  
}

  ngOnInit() {
   
   this.getAllArticles();
  
  
  }

//Fetch all articles
   getAllArticles() {
        this.branchService.getAllArticles()
		  .subscribe(
                data => this.articles = data,
                errorCode =>  this.statusCode = errorCode); 
                }


 
  
}
